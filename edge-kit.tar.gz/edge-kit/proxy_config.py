#!/usr/bin/python3
"""
Manual BrightData proxy config — safelink-bot.

Tujuan
------
Semua jalur keluar (setiap view) WAJIB lewat BrightData residential/ISP yang
di-input MANUAL oleh operator. Tidak ada nilai hardcoded di repo: file
proxy.env dibuat saat pertama kali bot dijalankan dan berisi:

    PROXY_HOST=brd.superproxy.io
    PROXY_PORT=44445
    PROXY_USER=brd-customer-hl_XXXX-zone-isp_proxy1-country-{country}-session-{session}
    PROXY_PASS=********
    PROXY_COUNTRY=id
    USE_PROXY=1

{country} dan {session} di-substitusi per view supaya setiap view = IP keluar baru
(inilah yang bikin hitungan dashboard publisher naik; IP sama = view di-dedupe).

Dipakai oleh:
  * sl_bot.py    -> prompt interaktif saat panel start (kalau dijalankan di TTY)
                    + command /proxy lewat Telegram buat set/ubah tanpa SSH
  * sl_worker.py -> reload proxy.env SEBELUM SETIAP VIEW, jadi proxy bisa diganti
                    dari panel tanpa restart worker
  * relay_engine.build_proxy() -> baca dari sini (fallback ke os.environ)
"""
import os
import sys
import json
import stat
import socket

HERE = os.path.dirname(os.path.abspath(__file__))
PROXY_FILE = os.path.join(HERE, "proxy.env")
DEFAULTS = {
    "PROXY_HOST": "brd.superproxy.io",
    "PROXY_PORT": "44445",
    "PROXY_USER": "",
    "PROXY_PASS": "",
    "PROXY_COUNTRY": "id",
    "USE_PROXY": "1",
}

EXAMPLE_USER = ("brd-customer-hl_XXXXXXXX-zone-isp_proxy1"
                "-country-{country}-session-{session}")


# --------------------------------------------------------------------- load
def load(path=PROXY_FILE):
    """-> dict of proxy settings (empty dict kalau belum pernah diset)."""
    if not os.path.exists(path):
        return {}
    out = {}
    for line in open(path):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def configured(path=PROXY_FILE):
    c = load(path)
    return bool(c.get("PROXY_HOST") and c.get("PROXY_USER") and c.get("PROXY_PASS"))


def export_env(cfg):
    """Tulis ke os.environ supaya relay_engine (dibaca saat build_proxy) lihat."""
    if not cfg:
        return
    os.environ["PROXY_HOST"] = cfg.get("PROXY_HOST", DEFAULTS["PROXY_HOST"])
    os.environ["PROXY_PORT"] = cfg.get("PROXY_PORT", DEFAULTS["PROXY_PORT"])
    os.environ["PROXY_USER_TEMPLATE"] = cfg.get("PROXY_USER", "")
    os.environ["PROXY_PASS"] = cfg.get("PROXY_PASS", "")
    os.environ["PROXY_COUNTRY"] = cfg.get("PROXY_COUNTRY", DEFAULTS["PROXY_COUNTRY"])
    os.environ["USE_PROXY"] = cfg.get("USE_PROXY", DEFAULTS["USE_PROXY"])


# --------------------------------------------------------------------- save
def save(cfg, path=PROXY_FILE):
    body = [
        "# BrightData proxy (manual) — ditulis oleh proxy_config.py",
        "# {country} dan {session} disubstitusi per view (session unik = IP unik).",
        "PROXY_HOST=%s" % cfg.get("PROXY_HOST", DEFAULTS["PROXY_HOST"]),
        "PROXY_PORT=%s" % cfg.get("PROXY_PORT", DEFAULTS["PROXY_PORT"]),
        "PROXY_USER=%s" % cfg.get("PROXY_USER", ""),
        "PROXY_PASS=%s" % cfg.get("PROXY_PASS", ""),
        "PROXY_COUNTRY=%s" % cfg.get("PROXY_COUNTRY", DEFAULTS["PROXY_COUNTRY"]),
        "USE_PROXY=%s" % cfg.get("USE_PROXY", DEFAULTS["USE_PROXY"]),
    ]
    with open(path, "w") as f:
        f.write("\n".join(body) + "\n")
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)   # 0600: isinya kredensial
    except Exception:
        pass
    export_env(cfg)
    return path


# --------------------------------------------------------------------- parse
def parse_line(line):
    """Terima salah satu format (yang paling gampang copy-paste dari BrightData):
       user:pass@host:port         |  host:port:user:pass
       user:pass                   (host/port default brd.superproxy.io:44445)
    -> dict atau None kalau tidak valid."""
    line = (line or "").strip()
    if not line:
        return None
    cfg = dict(DEFAULTS)
    if "@" in line and ":" in line:
        creds, hostpart = line.rsplit("@", 1)
        if ":" not in creds:
            return None
        u, p = creds.split(":", 1)
        # host boleh tanpa port: default 44445 (BrightData)
        if ":" in hostpart:
            h, prt = hostpart.split(":", 1)
            if not prt.isdigit():
                return None
        else:
            h, prt = hostpart, DEFAULTS["PROXY_PORT"]
        cfg.update(PROXY_USER=u.strip(), PROXY_PASS=p.strip(),
                   PROXY_HOST=h.strip(), PROXY_PORT=prt.strip())
    else:
        parts = line.split(":")
        if len(parts) == 4:
            h, prt, u, p = parts
            if prt.isdigit():
                cfg.update(PROXY_HOST=h.strip(), PROXY_PORT=prt.strip(),
                           PROXY_USER=u.strip(), PROXY_PASS=p.strip())
            else:                                     # user:pass:... salah bentuk
                return None
        elif len(parts) >= 2:
            cfg.update(PROXY_USER=parts[0].strip(),
                       PROXY_PASS=":".join(parts[1:]).strip())
        else:
            return None
    if not cfg["PROXY_USER"] or not cfg["PROXY_PASS"]:
        return None
    # placeholder penting: tanpa {session} tiap view keluar dari IP yang sama
    if "{session}" not in cfg["PROXY_USER"]:
        cfg["PROXY_USER"] = cfg["PROXY_USER"] + "-session-{session}"
    if "{country}" not in cfg["PROXY_USER"]:
        cfg["PROXY_USER"] = cfg["PROXY_USER"] + "-country-{country}"
    return cfg


# --------------------------------------------------------------------- check
def check(cfg, timeout=25):
    """Tes kredensial: request keluar lewat proxy ke service geo BrightData.
    -> (ok: bool, info: str)."""
    if not (cfg or {}).get("PROXY_USER") or not (cfg or {}).get("PROXY_PASS"):
        return False, "kredensial proxy belum diisi (PROXY_USER/PROXY_PASS kosong)"
    try:
        import requests
    except Exception as e:
        return False, "requests tidak ada: %s" % e

    host = cfg.get("PROXY_HOST") or DEFAULTS["PROXY_HOST"]
    port = cfg.get("PROXY_PORT") or DEFAULTS["PROXY_PORT"]
    country = cfg.get("PROXY_COUNTRY") or DEFAULTS["PROXY_COUNTRY"]
    # session acak tiap tes: sticky session lama bisa sudah mati (000/407),
    # itu bukan salah kredensial.
    import uuid as _uuid
    sess = "chk" + _uuid.uuid4().hex[:8]
    user = (cfg.get("PROXY_USER") or "").replace("{country}", country) \
                                        .replace("{session}", sess)
    auth = "http://%s:%s@%s:%s" % (user, cfg.get("PROXY_PASS"), host, port)
    proxies = {"http": auth, "https": auth}
    try:
        r = requests.get("https://geo.brdtest.com/mygeo.json", proxies=proxies,
                         timeout=timeout)
        if r.status_code == 407:
            return False, "407 Invalid Auth — user/pass proxy salah"
        if r.status_code == 403:
            return False, "403 — kredensial valid tapi request ditolak zona"
        if r.status_code != 200:
            return False, "HTTP %s dari proxy" % r.status_code
        try:
            j = r.json()
        except Exception:
            return True, "konek OK (%s) — respons non-JSON" % r.text[:60].strip()
        geo = j.get("geo") or {}
        ip = j.get("ip") or geo.get("ip")
        got_c = str(j.get("country") or geo.get("country") or "?").upper()
        city = geo.get("city") or "-"
        if not ip:
            # mygeo.json tidak memuat IP: ambil IP keluar biar kelihatan rotasinya
            try:
                r2 = requests.get("https://api.ipify.org?format=json", proxies=proxies,
                                  timeout=min(timeout, 15))
                ip = (r2.json() or {}).get("ip")
            except Exception:
                ip = None
        ip = ip or "?"
        if got_c != "?" and got_c.lower() != str(country).lower():
            return True, "⚠️ keluar dari %s (minta %s) · %s · %s" % (got_c, country.upper(), city, ip)
        asn = ((j.get("asn") or {}).get("org_name") or "-")
        return True, "%s / %s / %s · %s" % (got_c, city, ip, asn)
    except Exception as e:
        return False, ("gagal konek proxy: %s" % str(e)[:160])


def describe(cfg):
    if not cfg:
        return "belum diset"
    mask = cfg.get("PROXY_PASS", "")[:2] + "***"
    return ("%s:%s · %s:%s · country=%s · use_proxy=%s"
            % (cfg.get("PROXY_HOST"), cfg.get("PROXY_PORT"),
               cfg.get("PROXY_USER", "")[:64], mask,
               cfg.get("PROXY_COUNTRY"), cfg.get("USE_PROXY")))


# --------------------------------------------------------------------- prompt
def interactive(force=False, allow_skip=1):
    """Prompt manual di terminal. Return True kalau config valid & tersimpan.

    Dipanggil sl_bot.py saat start. Kalau stdin bukan TTY (systemd/detached),
    fungsi ini langsung return False tanpa memblok — panel tetap jalan pakai
    proxy.env yang sudah ada, dan operator bisa set lewat command /proxy.
    """
    have = load()
    tty = sys.stdin is not None and sys.stdin.isatty() and sys.stdout.isatty()
    if not tty:
        if have:
            export_env(have)
            return True
        print("[proxy] stdin bukan TTY dan proxy.env belum ada — set lewat "
              "command /proxy di Telegram.", flush=True)
        return False

    print("\n" + "=" * 66)
    print(" KONFIGURASI PROXY BRIGHTDATA (manual)")
    print("=" * 66)
    print(" Semua view keluar lewat proxy ini. Format yang diterima:")
    print("   user:pass@host:port")
    print("   host:port:user:pass")
    print(" Contoh user (dari dashboard BrightData -> zone isp_proxy1):")
    print("   %s" % EXAMPLE_USER)
    print(" {session} wajib ada: session unik = IP keluar unik tiap view.")
    print("-" * 66)
    if have:
        print(" Tersimpan sekarang: %s" % describe(have))
        print(" Enter = pakai yang tersimpan.")
    print("=" * 66)

    while True:
        try:
            line = input(" proxy> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[proxy] dibatalkan, pakai config tersimpan.")
            if have:
                export_env(have)
                return True
            return False
        if not line and have:
            export_env(have)
            print("[proxy] pakai config tersimpan.")
            return True
        if line.lower() in ("skip", "batal", "cancel") and have:
            export_env(have)
            return True
        cfg = parse_line(line)
        if not cfg:
            print(" [!] format salah. Contoh: "
                  "brd-customer-hl_XXXX-zone-isp_proxy1-country-{country}-session-{session}:PASS@brd.superproxy.io:44445")
            continue
        try:
            c = input(" country (default %s)> " % cfg["PROXY_COUNTRY"]).strip()
            if c:
                cfg["PROXY_COUNTRY"] = c.lower()
        except (EOFError, KeyboardInterrupt):
            pass
        print("[proxy] cek kredensial ...", end=" ", flush=True)
        ok, info = check(cfg)
        print("OK — %s" % info if ok else "GAGAL — %s" % info)
        if not ok:
            try:
                again = input(" simpan tetap? [y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                again = ""
            if again != "y":
                if have:
                    export_env(have)
                    return True
                continue
        save(cfg)
        print("[proxy] tersimpan -> %s" % PROXY_FILE)
        return True


def main():
    import argparse
    ap = argparse.ArgumentParser(description="set proxy manual safelink-bot")
    ap.add_argument("--line", help="user:pass@host:port atau host:port:user:pass")
    ap.add_argument("--country", default=None)
    ap.add_argument("--check", action="store_true", help="cuma tes config tersimpan")
    ap.add_argument("--show", action="store_true", help="tampilkan config tersimpan")
    a = ap.parse_args()
    if a.show:
        print(describe(load()) or "belum diset")
        return
    if a.check:
        cfg = load()
        if not cfg:
            print("belum diset")
            return
        ok, info = check(cfg)
        print(("OK — " if ok else "GAGAL — ") + info)
        return
    if a.line:
        cfg = parse_line(a.line)
        if not cfg:
            print("format salah")
            sys.exit(1)
        if a.country:
            cfg["PROXY_COUNTRY"] = a.country.lower()
        ok, info = check(cfg)
        print(("OK — " if ok else "GAGAL — ") + info)
        save(cfg)
        print("tersimpan:", describe(cfg))
        return
    interactive()


if __name__ == "__main__":
    main()
